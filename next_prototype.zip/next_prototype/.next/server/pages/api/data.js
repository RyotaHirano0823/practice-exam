(function() {
var exports = {};
exports.id = "pages/api/data";
exports.ids = ["pages/api/data"];
exports.modules = {

/***/ "./modules/database.ts":
/*!*****************************!*\
  !*** ./modules/database.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "sqlExecuter": function() { return /* binding */ sqlExecuter; }
/* harmony export */ });
/* harmony import */ var pg_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! pg-promise */ "pg-promise");
/* harmony import */ var pg_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(pg_promise__WEBPACK_IMPORTED_MODULE_0__);

const pgp = pg_promise__WEBPACK_IMPORTED_MODULE_0___default()({});
const config = {
  db: {
    // 設定項目: https://github.com/vitaly-t/pg-promise/wiki/Connection-Syntax
    host: "127.0.0.1",
    port: 5432,
    database: "mydb",
    user: "user",
    password: "7895123zxc",
    max: 10,
    // size of the connection pool
    query_timeout: 60000 // 60sec

  }
};
const sqlExecuter = pgp(config.db);

/***/ }),

/***/ "./pages/api/data.ts":
/*!***************************!*\
  !*** ./pages/api/data.ts ***!
  \***************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _modules_database__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../modules/database */ "./modules/database.ts");

/* harmony default export */ __webpack_exports__["default"] = (async (req, res) => {
  const data = await _modules_database__WEBPACK_IMPORTED_MODULE_0__.sqlExecuter.any("select 'DB参照したデータ' as any_column");
  res.status(200).json({
    data
  });
});

/***/ }),

/***/ "pg-promise":
/*!*****************************!*\
  !*** external "pg-promise" ***!
  \*****************************/
/***/ (function(module) {

"use strict";
module.exports = require("pg-promise");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/api/data.ts"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0X3Byb3RvdHlwZS8uL21vZHVsZXMvZGF0YWJhc2UudHMiLCJ3ZWJwYWNrOi8vbmV4dF9wcm90b3R5cGUvLi9wYWdlcy9hcGkvZGF0YS50cyIsIndlYnBhY2s6Ly9uZXh0X3Byb3RvdHlwZS9leHRlcm5hbCBcInBnLXByb21pc2VcIiJdLCJuYW1lcyI6WyJwZ3AiLCJwZ1Byb21pc2UiLCJjb25maWciLCJkYiIsImhvc3QiLCJwb3J0IiwiZGF0YWJhc2UiLCJ1c2VyIiwicGFzc3dvcmQiLCJtYXgiLCJxdWVyeV90aW1lb3V0Iiwic3FsRXhlY3V0ZXIiLCJyZXEiLCJyZXMiLCJkYXRhIiwic3RhdHVzIiwianNvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBRUEsTUFBTUEsR0FBRyxHQUFHQyxpREFBUyxDQUFDLEVBQUQsQ0FBckI7QUFDQSxNQUFNQyxNQUFNLEdBQUc7QUFDZEMsSUFBRSxFQUFFO0FBQ0g7QUFDQUMsUUFBSSxFQUFFLFdBRkg7QUFHSEMsUUFBSSxFQUFFLElBSEg7QUFJSEMsWUFBUSxFQUFFLE1BSlA7QUFLSEMsUUFBSSxFQUFFLE1BTEg7QUFNSEMsWUFBUSxFQUFFLFlBTlA7QUFPSEMsT0FBRyxFQUFFLEVBUEY7QUFPTTtBQUNUQyxpQkFBYSxFQUFFLEtBUlosQ0FRa0I7O0FBUmxCO0FBRFUsQ0FBZjtBQWFPLE1BQU1DLFdBQVcsR0FBR1gsR0FBRyxDQUFDRSxNQUFNLENBQUNDLEVBQVIsQ0FBdkIsQzs7Ozs7Ozs7Ozs7OztBQ2hCUDtBQUVBLCtEQUFlLE9BQU9TLEdBQVAsRUFBaUJDLEdBQWpCLEtBQThCO0FBRTVDLFFBQU1DLElBQUksR0FBRyxNQUFNSCw4REFBQSxDQUNMLGtDQURLLENBQW5CO0FBR0FFLEtBQUcsQ0FBQ0UsTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQ3BCRjtBQURvQixHQUFyQjtBQUdBLENBUkQsRTs7Ozs7Ozs7Ozs7QUNGQSx3QyIsImZpbGUiOiJwYWdlcy9hcGkvZGF0YS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBwZ1Byb21pc2UgZnJvbSBcInBnLXByb21pc2VcIjtcclxuXHJcbmNvbnN0IHBncCA9IHBnUHJvbWlzZSh7fSk7XHJcbmNvbnN0IGNvbmZpZyA9IHtcclxuXHRkYjoge1xyXG5cdFx0Ly8g6Kit5a6a6aCF55uuOiBodHRwczovL2dpdGh1Yi5jb20vdml0YWx5LXQvcGctcHJvbWlzZS93aWtpL0Nvbm5lY3Rpb24tU3ludGF4XHJcblx0XHRob3N0OiBcIjEyNy4wLjAuMVwiLFxyXG5cdFx0cG9ydDogNTQzMixcclxuXHRcdGRhdGFiYXNlOiBcIm15ZGJcIixcclxuXHRcdHVzZXI6IFwidXNlclwiLFxyXG5cdFx0cGFzc3dvcmQ6IFwiNzg5NTEyM3p4Y1wiLFxyXG5cdFx0bWF4OiAxMCwgLy8gc2l6ZSBvZiB0aGUgY29ubmVjdGlvbiBwb29sXHJcblx0XHRxdWVyeV90aW1lb3V0OiA2MDAwMCAvLyA2MHNlY1xyXG5cdH1cclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBzcWxFeGVjdXRlciA9IHBncChjb25maWcuZGIpO1xyXG4iLCJpbXBvcnQgeyBzcWxFeGVjdXRlciB9IGZyb20gXCIuLi8uLi9tb2R1bGVzL2RhdGFiYXNlXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBhc3luYyAocmVxOiBhbnksIHJlczogYW55KSA9PiB7XHJcblxyXG5cdGNvbnN0IGRhdGEgPSBhd2FpdCBzcWxFeGVjdXRlci5hbnkoXHJcbiAgICAgICAgICAgICAgIFwic2VsZWN0ICdEQuWPgueFp+OBl+OBn+ODh+ODvOOCvycgYXMgYW55X2NvbHVtblwiXHJcbiAgICAgICAgKTtcclxuXHRyZXMuc3RhdHVzKDIwMCkuanNvbih7XHJcblx0XHRkYXRhXHJcblx0fSk7XHJcbn07XHJcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInBnLXByb21pc2VcIik7OyJdLCJzb3VyY2VSb290IjoiIn0=