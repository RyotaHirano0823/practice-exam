(function() {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./modules/request.ts":
/*!****************************!*\
  !*** ./modules/request.ts ***!
  \****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getRequestInstance": function() { return /* binding */ getRequestInstance; }
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const serverSideBaseURL = "http://localhost:3000/api";
const clientSideBaseURL = "http://localhost:3000/api";
const requestInstance = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
  baseURL: serverSideBaseURL
});
const clientRequestInstance = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
  baseURL: clientSideBaseURL
});
const getRequestInstance = isServerSide => {
  if (isServerSide) {
    return requestInstance;
  }

  return clientRequestInstance;
};

/***/ }),

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _modules_request__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../modules/request */ "./modules/request.ts");

var _jsxFileName = "C:\\Users\\hrhku\\next_prototype\\pages\\index.tsx";


const Page = ({
  data
}) => {
  return data.map((d, index) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    children: [index, "\u756A\u76EE\u306E\u30C7\u30FC\u30BF: ", d.any_column]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 33
  }, undefined));
};

Page.getInitialProps = async ctx => {
  const request = (0,_modules_request__WEBPACK_IMPORTED_MODULE_1__.getRequestInstance)(Boolean(ctx.req));
  const res = await request.get("data").then(res => res);
  return res.data;
};

/* harmony default export */ __webpack_exports__["default"] = (Page);

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = require("axios");;

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-dev-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/index.tsx"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0X3Byb3RvdHlwZS8uL21vZHVsZXMvcmVxdWVzdC50cyIsIndlYnBhY2s6Ly9uZXh0X3Byb3RvdHlwZS8uL3BhZ2VzL2luZGV4LnRzeCIsIndlYnBhY2s6Ly9uZXh0X3Byb3RvdHlwZS9leHRlcm5hbCBcImF4aW9zXCIiLCJ3ZWJwYWNrOi8vbmV4dF9wcm90b3R5cGUvZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIiJdLCJuYW1lcyI6WyJzZXJ2ZXJTaWRlQmFzZVVSTCIsImNsaWVudFNpZGVCYXNlVVJMIiwicmVxdWVzdEluc3RhbmNlIiwiYXhpb3MiLCJiYXNlVVJMIiwiY2xpZW50UmVxdWVzdEluc3RhbmNlIiwiZ2V0UmVxdWVzdEluc3RhbmNlIiwiaXNTZXJ2ZXJTaWRlIiwiUGFnZSIsImRhdGEiLCJtYXAiLCJkIiwiaW5kZXgiLCJhbnlfY29sdW1uIiwiZ2V0SW5pdGlhbFByb3BzIiwiY3R4IiwicmVxdWVzdCIsIkJvb2xlYW4iLCJyZXEiLCJyZXMiLCJnZXQiLCJ0aGVuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxNQUFNQSxpQkFBaUIsR0FBRywyQkFBMUI7QUFDQSxNQUFNQyxpQkFBaUIsR0FBRywyQkFBMUI7QUFFQSxNQUFNQyxlQUFlLEdBQUdDLG1EQUFBLENBQWE7QUFDcENDLFNBQU8sRUFBRUo7QUFEMkIsQ0FBYixDQUF4QjtBQUlBLE1BQU1LLHFCQUFxQixHQUFHRixtREFBQSxDQUFhO0FBQzFDQyxTQUFPLEVBQUVIO0FBRGlDLENBQWIsQ0FBOUI7QUFJTyxNQUFNSyxrQkFBa0IsR0FBSUMsWUFBRCxJQUEyQjtBQUM1RCxNQUFJQSxZQUFKLEVBQWtCO0FBQ2pCLFdBQU9MLGVBQVA7QUFDQTs7QUFDRCxTQUFPRyxxQkFBUDtBQUNBLENBTE0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNYUDs7QUFFQSxNQUFNRyxJQUFjLEdBQUcsQ0FBQztBQUFFQztBQUFGLENBQUQsS0FBYztBQUNsQyxTQUFPQSxJQUFJLENBQUNDLEdBQUwsQ0FDSixDQUFDQyxDQUFELEVBQVNDLEtBQVQsa0JBQTBCO0FBQUEsZUFBTUEsS0FBTiw0Q0FBcUJELENBQUMsQ0FBQ0UsVUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRHRCLENBQVA7QUFHRixDQUpEOztBQUtBTCxJQUFJLENBQUNNLGVBQUwsR0FBdUIsTUFBT0MsR0FBUCxJQUFvQjtBQUMxQyxRQUFNQyxPQUFPLEdBQUdWLG9FQUFrQixDQUFDVyxPQUFPLENBQUNGLEdBQUcsQ0FBQ0csR0FBTCxDQUFSLENBQWxDO0FBQ0EsUUFBTUMsR0FBRyxHQUFHLE1BQU1ILE9BQU8sQ0FBQ0ksR0FBUixDQUFZLE1BQVosRUFBb0JDLElBQXBCLENBQXlCRixHQUFHLElBQUlBLEdBQWhDLENBQWxCO0FBQ0EsU0FBT0EsR0FBRyxDQUFDVixJQUFYO0FBQ0EsQ0FKRDs7QUFLQSwrREFBZUQsSUFBZixFOzs7Ozs7Ozs7OztBQ2JBLG1DOzs7Ozs7Ozs7OztBQ0FBLG1EIiwiZmlsZSI6InBhZ2VzL2luZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5jb25zdCBzZXJ2ZXJTaWRlQmFzZVVSTCA9IFwiaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaVwiO1xyXG5jb25zdCBjbGllbnRTaWRlQmFzZVVSTCA9IFwiaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaVwiO1xyXG5cclxuY29uc3QgcmVxdWVzdEluc3RhbmNlID0gYXhpb3MuY3JlYXRlKHtcclxuXHRiYXNlVVJMOiBzZXJ2ZXJTaWRlQmFzZVVSTFxyXG59KTtcclxuXHJcbmNvbnN0IGNsaWVudFJlcXVlc3RJbnN0YW5jZSA9IGF4aW9zLmNyZWF0ZSh7XHJcblx0YmFzZVVSTDogY2xpZW50U2lkZUJhc2VVUkxcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3QgZ2V0UmVxdWVzdEluc3RhbmNlID0gKGlzU2VydmVyU2lkZTogYm9vbGVhbikgPT4ge1xyXG5cdGlmIChpc1NlcnZlclNpZGUpIHtcclxuXHRcdHJldHVybiByZXF1ZXN0SW5zdGFuY2U7XHJcblx0fVxyXG5cdHJldHVybiBjbGllbnRSZXF1ZXN0SW5zdGFuY2U7XHJcbn07XHJcbiIsImltcG9ydCB7IE5leHRQYWdlIH0gZnJvbSAnbmV4dCdcbmltcG9ydCB7IGdldFJlcXVlc3RJbnN0YW5jZSB9IGZyb20gXCIuLi9tb2R1bGVzL3JlcXVlc3RcIjtcblxuY29uc3QgUGFnZTogTmV4dFBhZ2UgPSAoeyBkYXRhIH0pID0+IHtcbiAgIHJldHVybiBkYXRhLm1hcChcbiAgICAgIChkOiBhbnksIGluZGV4Om51bWJlcikgPT4gPGRpdj57aW5kZXh955Wq55uu44Gu44OH44O844K/OiB7ZC5hbnlfY29sdW1ufTwvZGl2PlxuICAgKVxufVxuUGFnZS5nZXRJbml0aWFsUHJvcHMgPSBhc3luYyAoY3R4OiBhbnkpID0+IHtcblx0Y29uc3QgcmVxdWVzdCA9IGdldFJlcXVlc3RJbnN0YW5jZShCb29sZWFuKGN0eC5yZXEpKTtcblx0Y29uc3QgcmVzID0gYXdhaXQgcmVxdWVzdC5nZXQoXCJkYXRhXCIpLnRoZW4ocmVzID0+IHJlcyk7XG5cdHJldHVybiByZXMuZGF0YTtcbn1cbmV4cG9ydCBkZWZhdWx0IFBhZ2VcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImF4aW9zXCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7OyJdLCJzb3VyY2VSb290IjoiIn0=