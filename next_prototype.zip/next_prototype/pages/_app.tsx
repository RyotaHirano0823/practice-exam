import { AppProps } from 'next/app'

const MyApp = ({ Component, pageProps }: AppProps) => {
	return ;
}
export default MyApp
